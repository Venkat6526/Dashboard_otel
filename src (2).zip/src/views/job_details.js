import React from 'react';
function App() {
   return (
      <div className="App">
         Abroad & Local Jobs Coming Soon!
      </div>
   );
}
export default App;