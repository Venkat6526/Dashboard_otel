// var server_url="https://otel.co.in:5000";
// var portal_url="http://127.0.0.1:3000";
// var image_url="https://otel.co.in/uploads";
// var local_url="https://otel.co.in:5000";
// var base_url="https://otel.co.in:5000";
// var server_url="http://localhost:5000";
var portal_url="https://mindroit.net:5000";
var image_url="https://mindroit.net:5000";
var server_url="https://mindroit.net:5000";
var mail_url="https://mindroit.net";
var whatsapp_url="https://mindroit.net/otel_whatsapp";
var pdf_url="https://mindroit.net/otel_pdf";
var otp_url="https://mindroit.net/otel_otp";
export default  {
  mail_url,
  server_url,
  portal_url,
  image_url,
  whatsapp_url,
  pdf_url,
  otp_url
    // local_url,
  // base_url
};
// http://localhost:5000