const Image = {
  SCANNER: require("./scanner.jpg"),
  IROLL: require("./iRoll.jpg"),
  greenTick: require("./greenTick.jpg"),
  wrong: require("./wrong.png"),
};
export default Image;
